export { HomeView } from "./home";
export { MiscView } from "./misc";
export { UploadView } from "./upload";
export { CreateView } from "./create";
